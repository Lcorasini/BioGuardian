package com.example.bioguardian

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BioGuardianApp() }
    }
}

@Composable
fun BioGuardianApp() {
    Surface(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFFCF6)) // cor de fundo creme
    ) {
        BioGuardianScreen(
            onStart = { /* ação do botão "Começar" */ },
            onINaturalist = { /* ação do link "Entrar com iNaturalist" */ }
        )
    }
}

@Composable
fun BioGuardianScreen(
    onStart: () -> Unit,
    onINaturalist: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Logo (apenas a imagem)
        Image(
            painter = painterResource(id = R.drawable.logo_bioguardian),
            contentDescription = "Logo BioGuardian",
            modifier = Modifier.size(180.dp)
        )

        // Título
        Text(
            text = "BioGuardian",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF2F6B4F),
            textAlign = TextAlign.Center
        )

        // Descrição
        Text(
            text = "Monitore e contribua para a biodiversidade da sua cidade.",
            fontSize = 16.sp,
            color = Color(0xFF333333),
            textAlign = TextAlign.Center
        )

        // Botão "Começar"
        Button(
            onClick = onStart,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2F6B4F)),
            shape = RoundedCornerShape(50)
        ) {
            Text("Começar", fontSize = 16.sp, color = Color.White)
        }

        // Texto clicável "Entrar com iNaturalist"
        Text(
            text = "Entrar com iNaturalist",
            color = Color(0xFF2F6B4F),
            fontSize = 16.sp,
            modifier = Modifier.clickable { onINaturalist() }
        )
    }
}
@Preview(showBackground = true, showSystemUi = true)
@Composable
fun PreviewBioGuardianScreen() {
    BioGuardianApp()
}